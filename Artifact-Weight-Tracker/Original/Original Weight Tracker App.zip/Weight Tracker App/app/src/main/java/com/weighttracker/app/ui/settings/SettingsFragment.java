package com.weighttracker.app.ui.settings;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;


import com.weighttracker.app.data.GoalDatabase;
import com.weighttracker.app.databinding.FragmentSettingsBinding;

/**
 * This screen lets the user:
 * - enter or update goal weight
 * - enter a phone number for SMS
 * - turn SMS notifications on or off
 * - log out of the app
 */
public class SettingsFragment extends Fragment {

    private FragmentSettingsBinding binding;
    private boolean ignoreSwitchChange = false;
    private ActivityResultLauncher<String> requestSmsPermissionLauncher;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestSmsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    SharedPreferences prefs = requireActivity().getSharedPreferences("myprefs", Context.MODE_PRIVATE);
                    String username = prefs.getString("logged_in_username", "");

                    if (isGranted) {
                        // Reset the denial count if they finally allow it
                        prefs.edit()
                                .putBoolean(username + "_notifications_enabled", true)
                                .putInt(username + "_sms_denied_count", 0)
                                .apply();

                        if (binding != null) {
                            ignoreSwitchChange = true;
                            binding.notificationSwitch.setChecked(true);
                            ignoreSwitchChange = false;
                        }

                        Toast.makeText(getContext(), "SMS alerts enabled", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        // They denied SMS permission
                        prefs.edit().putBoolean(username + "_notifications_enabled", false).apply();

                        if (binding != null) {
                            ignoreSwitchChange = true;
                            binding.notificationSwitch.setChecked(false);
                            ignoreSwitchChange = false;
                        }

                        if (!shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)) {
                            // Update and check denial count manually
                            int denialCount = prefs.getInt(username + "_sms_denied_count", 0) + 1;
                            prefs.edit().putInt(username + "_sms_denied_count", denialCount).apply();

                            if (denialCount >= 3) {
                                // Show warning only after 2 full denials and a third toggle
                                Toast.makeText(getContext(),
                                        "You previously declined SMS alerts. Go into app settings to enable them.",
                                        Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getContext(), "SMS permission denied", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // They denied, but system still allows prompting again
                            Toast.makeText(getContext(), "SMS permission denied", Toast.LENGTH_SHORT).show();
                        }

                    }
                }
        );
    }

    /**
     * Loads the layout and connects to view binding.
     *
     * @param inflater Used to inflate the layout.
     * @param container The parent view that the fragment is attached to.
     * @param savedInstanceState Not used.
     * @return The root view of this fragment.
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSettingsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    /**
     * After the view loads, set up all input fields, switch, and button.
     *
     * @param view The root view of this fragment.
     * @param savedInstanceState Not used.
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SharedPreferences prefs = requireActivity().getSharedPreferences("myprefs", Context.MODE_PRIVATE);
        String username = prefs.getString("logged_in_username", "");

        // Fill phone number input if already saved
        String savedPhone = prefs.getString(username + "_phone_number", "");
        binding.phoneNumberInput.setText(savedPhone);

        try (GoalDatabase db = new GoalDatabase(requireContext())) {

            // Load saved goal weight into the input
            float savedGoal = db.getGoalWeight(username);
            if (savedGoal != -1) {
                binding.goalWeightInput.setText(String.valueOf(savedGoal));
            }

            // Set the switch to saved state (on or off)
            boolean isEnabled = prefs.getBoolean(username + "_notifications_enabled", false);
            binding.notificationSwitch.setChecked(isEnabled);

            // Handle switch toggle for enabling/disabling notifications
            binding.notificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (ignoreSwitchChange) return;

                SharedPreferences.Editor editor = prefs.edit();

                if (isChecked) {
                    if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                            == PERMISSION_GRANTED) {

                        // Permission already granted
                        Toast.makeText(getContext(), "SMS alerts enabled", Toast.LENGTH_SHORT).show();
                        editor.putBoolean(username + "_notifications_enabled", true);
                        editor.apply();

                    } else {
                        // Get previous denial count
                        int denialCount = prefs.getInt(username + "_sms_denied_count", 0);

                        if (!shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)) {
                            denialCount++;  // Pretend this next denial is about to happen
                            prefs.edit().putInt(username + "_sms_denied_count", denialCount).apply();

                            if (denialCount >= 3) {
                                Toast.makeText(getContext(),
                                        "You previously declined SMS alerts. Go into app settings to enable them.",
                                        Toast.LENGTH_LONG).show();
                            } else {
                                requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                            }
                        } else {
                            // First or second denial — still show system dialog
                            requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                        }

                        ignoreSwitchChange = true;
                        binding.notificationSwitch.setChecked(false);
                        ignoreSwitchChange = false;
                    }

                } else {
                    // They turned off the switch manually
                    editor.putBoolean(username + "_notifications_enabled", false);
                    editor.apply();
                }
            });


            // Save new goal weight if user edits it
            binding.goalWeightInput.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String input = s.toString().trim();
                    if (!input.isEmpty()) {
                        try {
                            float goalWeight = Float.parseFloat(input);

                            boolean saved = db.saveGoalWeight(username, goalWeight);
                            if (saved) {
                                // Reset the goal reached flag
                                prefs.edit().putBoolean(username + "_goal_reached", false).apply();
                            }

                        } catch (NumberFormatException e) {
                            Toast.makeText(getContext(), "Invalid number", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                @Override public void afterTextChanged(Editable s) {}
            });

            // Save phone number as the user types it
            binding.phoneNumberInput.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    prefs.edit()
                            .putString(username + "_phone_number", s.toString().trim())
                            .apply();
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }

        // Log out the user if logout button is clicked
        binding.logoutButton.setOnClickListener(v -> logOut());
    }

    /**
     * Cleanup the binding to avoid memory leaks
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    /**
     * Logs the user out and sends them back to the login screen
     */
    private void logOut() {
        SharedPreferences sharedPref = requireActivity().getSharedPreferences("myprefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.remove("logged_in_username");
        editor.apply();

        Intent intent = new Intent(getActivity(), com.weighttracker.app.ui.login.LoginActivity.class);
        startActivity(intent);
        requireActivity().finish(); // Prevents user from pressing "back" to return here
    }
}