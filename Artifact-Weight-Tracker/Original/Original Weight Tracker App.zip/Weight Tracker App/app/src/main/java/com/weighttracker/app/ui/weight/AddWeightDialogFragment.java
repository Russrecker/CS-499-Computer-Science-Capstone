package com.weighttracker.app.ui.weight;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import com.weighttracker.app.R;
import com.weighttracker.app.data.GoalDatabase;
import com.weighttracker.app.data.WeightDatabase;

import java.util.Calendar;
import java.util.Locale;

import model.WeightEntry;

/**
 * This is the screen where the user adds or edits a weight entry.
 * It checks if the goal is reached and sends an SMS if alerts are on.
 */
public class AddWeightDialogFragment extends DialogFragment {

    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        Toast.makeText(getContext(), "Permission granted. Please press 'Add' again.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "SMS permission denied", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    /**
     * Lets the screen get the new weight and date after it's added.
     */
    public interface AddWeightDialogListener {
        void onWeightEntry(String date, String weight);
    }

    /**
     * This sets who gets the new weight info after it's added.
     */
    public void setListener(AddWeightDialogListener listener) {
        this.mListener = listener;
    }

    private AddWeightDialogListener mListener;

    private WeightDatabase weightDatabase;

    private WeightEntry existingEntry;

    /**
     * Builds and shows the add weight dialog.
     * If editing an entry, it fills in the existing values.
     *
     * @param savedInstanceState Not used.
     * @return The dialog that lets the user enter a new weight or update it.
     */
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        // Check if editing an entry
        if (getArguments() != null) {
            String date = getArguments().getString("date", "");
            String weight = getArguments().getString("weight", "");
            int id = getArguments().getInt("id", -1);
            existingEntry = new WeightEntry(id, date, weight);
        }

        weightDatabase = new WeightDatabase(requireContext());

        // Load the add weight screen layout
        View addWeightScreen = getLayoutInflater().inflate(R.layout.add_weight_dialog, null);
        EditText dateField = addWeightScreen.findViewById(R.id.date_input);
        EditText weightField = addWeightScreen.findViewById(R.id.weight_input);

        // Fill in values if editing
        if (existingEntry != null) {
            dateField.setText(existingEntry.getDate());
            weightField.setText(existingEntry.getWeight().replace(" lbs", ""));
        }

        // Set up DatePickerDialog on click
        dateField.setOnClickListener(v -> {
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog picker = new DatePickerDialog(
                    requireContext(),
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        // Format: MM/DD/YYYY
                        String selectedDate = (selectedMonth + 1) + "/" + selectedDay + "/" + selectedYear;
                        dateField.setText(selectedDate);
                    },
                    year, month, day
            );

            picker.show();
        });

        // Create the dialog box
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle("Add Weight")
                .setView(addWeightScreen)
                .setPositiveButton("Add", null)
                .setNegativeButton("Cancel", null);

        AlertDialog dialog = builder.create();

        // Override "Add" click to validate first
        dialog.setOnShowListener(dialogInterface -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String dateInput = dateField.getText().toString().trim();
            String weightInput = weightField.getText().toString().trim();

            if (dateInput.isEmpty() || weightInput.isEmpty()) {
                Toast.makeText(getContext(), "Please fill out both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            float weightValue;
            try {
                weightValue = Float.parseFloat(weightInput);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Please enter a valid number for weight", Toast.LENGTH_SHORT).show();
                return;
            }
            // When user tries to enter more than 1000 lbs
            if (weightValue >= 1000f) {
                Toast.makeText(getContext(), "I don't think you're over 1000 lbs!", Toast.LENGTH_SHORT).show();
                return;
            }

            String weight = String.format(Locale.US, "%.2f", weightValue) + " lbs";

            SharedPreferences prefs = requireActivity().getSharedPreferences("myprefs", Context.MODE_PRIVATE);
            String username = prefs.getString("logged_in_username", "");
            boolean success;

            // Save to database
            if (existingEntry != null) {
                success = weightDatabase.updateWeight(existingEntry.getId(), dateInput, weight);
            } else {
                long result = weightDatabase.addWeight(username, dateInput, weight);
                success = result != -1;
            }

            if (success) {
                mListener.onWeightEntry(dateInput, weight);

                float goalWeight;
                try (GoalDatabase goalDb = new GoalDatabase(requireContext())) {
                    goalWeight = goalDb.getGoalWeight(username);
                }

                float enteredWeight = Float.parseFloat(weight.replace(" lbs", ""));
                boolean notificationsOn = prefs.getBoolean(username + "_notifications_enabled", false);

                boolean goalReached = prefs.getBoolean(username + "_goal_reached", false);

                // Check if user met goal
                boolean metGoal = enteredWeight <= goalWeight;
                if (notificationsOn && !goalReached && metGoal && goalWeight > 0) {
                    Toast.makeText(getContext(), "Congratulations! You reached your goal weight of " + goalWeight +
                            " lbs!", Toast.LENGTH_LONG).show();
                    
                    // Send SMS
                    if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                            == PERMISSION_GRANTED) {
                        String phoneNumber = prefs.getString(username + "_phone_number", "").trim();
                        if (!phoneNumber.isEmpty()) {
                            String message = "Congratulations! You reached your goal weight of " + goalWeight + " lbs!";
                            SmsManager sms = SmsManager.getDefault();
                            sms.sendTextMessage(phoneNumber, null, message, null, null);
                        }

                    } else {
                        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                    }

                    // Only send once
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putBoolean(username + "_goal_reached", true);
                    editor.apply();
                }
                dialog.dismiss();
            }
        }));
        return dialog;
    }

    /**
     * Creates a new dialog instance when editing a weight entry.
     *
     * @param entry The entry to pre-fill.
     * @return A filled-out dialog ready to display.
     */
    public static AddWeightDialogFragment newInstance(WeightEntry entry) {
        AddWeightDialogFragment fragment = new AddWeightDialogFragment();
        Bundle args = new Bundle();
        args.putString("date", entry.getDate());
        args.putString("weight", entry.getWeight());
        args.putInt("id", entry.getId());
        fragment.setArguments(args);
        return fragment;
    }

    /**
     * Runs when the dialog connects to the screen.
     * Makes sure the screen can listen for added weight.
     *
     * @param context The screen this dialog is attached to.
     */
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        // Only try to set the listener if it hasn't been set manually
        if (mListener == null) {
            Fragment parent = getParentFragment();
            if (parent instanceof AddWeightDialogListener) {
                mListener = (AddWeightDialogListener) parent;
            }
        }
    }
}
