package com.weighttracker.app;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.weighttracker.app.databinding.ActivityMainBinding;

/**
 * This is the main screen that controls everything in the app.
 * It switches between the weight and settings screens and shows the + button.
 */
public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    /**
     * Called when the app first starts up.
     * Sets up the layout, navigation, and the + button.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Grabs everything from the layout
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Makes the status bar icons dark so they show on a light background
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        // Makes sure the + button stays in front of everything
        binding.AddWeight.bringToFront();

        // When I click the + button, check if I’m on the weight screen and show the add weight popup
        binding.AddWeight.setOnClickListener(view -> {
            NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.nav_host_fragment_activity_main);
            if (navHostFragment != null) {
                Fragment currentFragment = navHostFragment.getChildFragmentManager().getFragments().get(0);
                if (currentFragment instanceof com.weighttracker.app.ui.weight.WeightFragment) {
                    ((com.weighttracker.app.ui.weight.WeightFragment) currentFragment).addWeightEntry();
                }
            }
        });


        // These are the two main screens (weight + settings)
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_weight, R.id.navigation_settings).build();

        // This will help control screen changes
        NavController navController = null;

        // Get the thing that controls switching between screens
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment_activity_main);

        if (navHostFragment != null) {
            // Handle screen switching and the nav bar
            navController = navHostFragment.getNavController();
            NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
            NavigationUI.setupWithNavController(binding.navView, navController);
        }

        // This hides the FAB on settings and shows it on the weight screen only
        if (navController != null) {
            navController.addOnDestinationChangedListener((controller, destination, arguments) -> {
                if (destination.getId() == R.id.navigation_weight) {
                    binding.AddWeight.show();
                } else {
                    binding.AddWeight.hide();
                }
            });
        }
    }
}
