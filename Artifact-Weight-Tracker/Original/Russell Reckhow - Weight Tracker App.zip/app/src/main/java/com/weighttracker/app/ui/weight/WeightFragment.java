package com.weighttracker.app.ui.weight;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;

import com.weighttracker.app.data.WeightDatabase;
import com.weighttracker.app.databinding.FragmentWeightBinding;

import java.util.ArrayList;
import java.util.List;

import model.WeightEntry;

/**
 * This screen shows all your weight entries in a list.
 * You can add, edit, or delete entries here.
 */
public class WeightFragment extends Fragment implements AddWeightDialogFragment.AddWeightDialogListener {

    private FragmentWeightBinding binding;
    private final List<WeightEntry> entryList = new ArrayList<>();
    private WeightAdapter adapter;
    private WeightDatabase weightDatabase;

    /**
     * Called when this screen is first loaded.
     * Sets up everything including the list and database.
     */
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        // Connect this screen to the layout
        binding = FragmentWeightBinding.inflate(inflater, container, false);

        // Connect to the weight database
        weightDatabase = new WeightDatabase(requireContext());

        // Load saved weight entries
        loadWeightEntries();

        // Set up the list and what happens when edit/delete is clicked
        adapter = new WeightAdapter(entryList, new WeightAdapter.WeightItemActionListener() {
            @Override
            public void onEditRequested(WeightEntry entry) {
                AddWeightDialogFragment dialog = AddWeightDialogFragment.newInstance(entry);
                dialog.setListener(WeightFragment.this);
                dialog.show(getParentFragmentManager(), "EditWeightDialog");

            }


            @Override
            public void onDeleteRequested(WeightEntry entry) {
                // When delete is clicked, show a confirm box
                confirmDelete(entry);
            }
        });

        // Hook the adapter to the list
        binding.weightList.setAdapter(adapter);

        // Add a line between each row in the list
        DividerItemDecoration divider = new DividerItemDecoration(
                binding.weightList.getContext(),
                DividerItemDecoration.VERTICAL
        );
        binding.weightList.addItemDecoration(divider);


        return binding.getRoot();

    }

    /**
     * Gets all weight entries saved for the user and puts them in the list.
     */
    private void loadWeightEntries() {
        entryList.clear();

        // Get the username of the logged-in user
        SharedPreferences prefs = requireActivity().getSharedPreferences("myprefs", Context.MODE_PRIVATE);
        String username = prefs.getString("logged_in_username", "");

        // Grab the weights from the database for this user
        Cursor cursor = weightDatabase.getUserWeights(username);
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            String weight = cursor.getString(cursor.getColumnIndexOrThrow("weight"));
            entryList.add(new WeightEntry(id, date, weight));
        }
        cursor.close();
    }

    /**
     * Shows a confirm box before deleting an entry
     *
     * @param entry the weight entry to delete
     */
    private void confirmDelete(WeightEntry entry) {
        new android.app.AlertDialog.Builder(requireContext())
                .setTitle("Delete Entry")
                .setMessage("Are you sure you want to delete this weight entry?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    int position = entryList.indexOf(entry);
                    weightDatabase.deleteWeight(entry.getId());
                    entryList.remove(position);
                    adapter.notifyItemRemoved(position);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Called when the screen is being destroyed.
     * This clears the binding to avoid memory leaks.
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    /**
     * Called when the user taps the add button.
     * Opens the add weight screen.
     */
    public void addWeightEntry() {
        AddWeightDialogFragment dialog = new AddWeightDialogFragment();
        dialog.setListener(this);
        dialog.show(getParentFragmentManager(), "AddWeightDialog");
    }

    /**
     * This is triggered after a new weight entry is added.
     * It reloads the list to show the new data.
     *
     * @param date the date of the new entry
     * @param weight the weight value
     */
    @Override
    public void onWeightEntry(String date, String weight) {
        loadWeightEntries();
        adapter.notifyDataSetChanged();
    }

}