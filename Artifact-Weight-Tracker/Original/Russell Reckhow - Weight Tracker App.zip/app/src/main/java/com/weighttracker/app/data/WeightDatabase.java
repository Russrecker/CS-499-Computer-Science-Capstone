package com.weighttracker.app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * This sets up the database for saving weight entries for each user.
 */
public class WeightDatabase extends SQLiteOpenHelper {

    // Name of the weight database and version number
    private static final String DATABASE_NAME = "weight.db";
    private static final int VERSION = 2;

    /**
     * Creates or opens the weight database.
     *
     * @param context The context of the app using this database.
     */
    public WeightDatabase(Context context) { super(context, DATABASE_NAME, null, VERSION);
    }

    /**
     * Holds the table and column names for weight entries.
     */
    private static final class weightTable {
        private static final String TABLE = "weights";
        private static final String col_id = "_id";
        private static final String col_username = "username";
        private static final String col_date = "date";
        private static final String col_weight = "weight";
    }

    /**
     * Runs the first time the database is created.
     * Sets up the table for saving weight entries.
     *
     * @param db The database where the table will be created.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + weightTable.TABLE + " (" +
                weightTable.col_id + " integer primary key autoincrement, " +
                weightTable.col_username + " text, " +  // ← NEW
                weightTable.col_date + " text, " +
                weightTable.col_weight + " text)");
    }

    /**
     * Runs when the database version changes.
     * Deletes the old table and creates a new one.
     *
     * @param db The database.
     * @param oldVersion The previous version number.
     * @param newVersion The new version number.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + weightTable.TABLE);
        onCreate(db);
    }

    /**
     * Adds a new weight entry for the user.
     *
     * @param username The user who the entry belongs to.
     * @param date The date of the weight entry.
     * @param weight The weight value.
     * @return The row ID of the inserted entry, or -1 if it failed.
     */
    public long addWeight(String username, String date, String weight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(weightTable.col_username, username); // ← NEW
        values.put(weightTable.col_date, date);
        values.put(weightTable.col_weight, weight);

        return db.insert(weightTable.TABLE, null, values);
    }

    /**
     * Gets all weight entries for the user, ordered by newest first.
     *
     * @param username The username to look up.
     * @return A Cursor pointing to the user's weight records.
     */
    public Cursor getUserWeights(String username) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + weightTable.TABLE +
                " WHERE " + weightTable.col_username + " = ?" +
                " ORDER BY " + weightTable.col_id + " DESC";

        return db.rawQuery(sql, new String[]{username});
    }

    /**
     * Deletes a weight entry by ID.
     *
     * @param id The ID of the entry to delete.
     */
    public void deleteWeight(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(weightTable.TABLE, weightTable.col_id + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    /**
     * Updates a weight entry with a new date and weight.
     *
     * @param id The ID of the entry to update.
     * @param date The new date.
     * @param weight The new weight value.
     * @return true if the update worked, false if it didn't.
     */
    public boolean updateWeight(int id, String date, String weight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(weightTable.col_date, date);
        values.put(weightTable.col_weight, weight);

        int rows = db.update(weightTable.TABLE, values, weightTable.col_id + " = ?", new String[]{String.valueOf(id)});
        db.close();

        return rows > 0;
    }
}
