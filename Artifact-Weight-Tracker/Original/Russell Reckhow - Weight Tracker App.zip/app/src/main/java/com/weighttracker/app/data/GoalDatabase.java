package com.weighttracker.app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * This sets up the database for saving goal weights for each user.
 */
public class GoalDatabase extends SQLiteOpenHelper {

    // Name of the goal database and version number
    private static final String DATABASE_NAME = "goal.db";
    private static final int VERSION = 1;

    /**
     * Creates or opens the goal database.
     *
     * @param context The context of the app using this database.
     */
    public GoalDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /**
     * Holds the table and column names for user goals.
     */
    private static final class goalTable {
        private static final String TABLE = "user_goals";
        private static final String col_username = "username";
        private static final String col_goal_weight = "goal_weight";
    }

    /**
     * Runs the first time the database is created.
     * Sets up the table for saving goal weights.
     *
     * @param db The database where the table will be created.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + goalTable.TABLE + " (" +
                goalTable.col_username + " text primary key, " +
                goalTable.col_goal_weight + " real)");
    }

    /**
     * Runs when the database version changes.
     * Drops the old table and creates a new one.
     *
     * @param db The database.
     * @param oldVersion The previous version number.
     * @param newVersion The new version number.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + goalTable.TABLE);
        onCreate(db);
    }

    /**
     * Saves or updates the user's goal weight.
     *
     * @param username The user whose goal is being saved.
     * @param goalWeight The goal weight to save.
     * @return true if the goal was saved, false if it failed.
     */
    public boolean saveGoalWeight(String username, float goalWeight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(goalTable.col_username, username);
        values.put(goalTable.col_goal_weight, goalWeight);

        // Insert or update the goal using conflict replace
        long rowId = db.insertWithOnConflict(goalTable.TABLE, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        return rowId != -1;
    }

    /**
     * Gets the saved goal weight for the given user.
     *
     * @param username The username to look up.
     * @return The goal weight, or -1 if not found.
     */
    public float getGoalWeight(String username) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select " + goalTable.col_goal_weight + " from " + goalTable.TABLE +
                " where " + goalTable.col_username + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[] { username });
        float goalWeight = -1;
        if (cursor.moveToFirst()) {
            goalWeight = cursor.getFloat(0);
        }
        cursor.close();

        return goalWeight;
    }
}
