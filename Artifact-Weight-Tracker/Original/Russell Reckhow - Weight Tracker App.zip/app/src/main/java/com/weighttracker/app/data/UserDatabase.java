package com.weighttracker.app.data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;

/**
 * Sets up and manages the database for storing usernames and passwords.
 */
public class UserDatabase extends SQLiteOpenHelper {

    // Name fo the database and version number
    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;

    /**
     * Creates or opens the users database.
     *
     * @param context The context of the app using this database.
     */
    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /**
     * Holds the table and column names used in the users table.
     */
    private static final class userTable {
        private static final String TABLE = "users";
        private static final String col_id = "_id";
        private static final String col_username = "username";
        private static final String col_password = "password";
    }

    /**
     * Called the first time the database is created.
     *
     * @param db The database where the table will be created.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + userTable.TABLE + " (" +
                userTable.col_id + " integer primary key autoincrement, " +
                userTable.col_username + " text unique, " +
                userTable.col_password + " text)");
    }

    /**
     * Called when the app updates and the database version changes.
     * Deletes the old table and creates a new one.
     *
     * @param db The database.
     * @param oldVersion The previous version number.
     * @param newVersion The new version number.
     */
    // This runs when the database version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + userTable.TABLE);
        onCreate(db);
    }

    /**
     * Adds a new user to the database.
     *
     * @param username The new user's username.
     * @param password The new user's password.
     * @return true if the user was added, false if it failed.
     */
    // Adds a new user to the table
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(userTable.col_username, username);
        values.put(userTable.col_password, password);

        long rowId = db.insert(userTable.TABLE, null, values);
        return rowId != -1; // Return true if it worked
    }

    /**
     * Checks if the username and password match a user in the database.
     *
     * @param username The username to check.
     * @param password The password to check.
     * @return true if a match is found, or false if not.
     */
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + userTable.TABLE +
                " where " + userTable.col_username + " = ? and " +
                userTable.col_password + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[] { username, password });
        boolean valid = cursor.moveToFirst();  // True if match found
        cursor.close();

        return valid;
    }
}
