package com.weighttracker.app.ui.login;

import com.weighttracker.app.data.UserDatabase;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.weighttracker.app.MainActivity;
import com.weighttracker.app.R;

import java.util.Objects;

/**
 * This screen handles user login and account creation.
 * Users can log in or create a new account to get into the app.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private UserDatabase db;

    /**
     * Runs when the login screen is opened.
     * Sets up the layout, hides the action bar, and connects the buttons.
     *
     * @param savedInstanceState Saved instance state for screen reloading (not used here).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Don’t need the action bar on the login screen, so hide it
        Objects.requireNonNull(getSupportActionBar()).hide();

        // Set up the database
        db = new UserDatabase(getApplicationContext());

        // Hook up the UI elements
        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.loginButton);
        Button createButton = findViewById(R.id.createButton);

        // Log in when button is clicked
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
            } else if (db.validateUser(username, password)) {

                // Save logged in username to SharedPreferences
                getSharedPreferences("myprefs", MODE_PRIVATE)
                        .edit()
                        .putString("logged_in_username", username)
                        .apply();

                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        // Create new account when button is clicked
        createButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
            } else if (db.addUser(username, password)) {
                Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show();

                // Save newly created username to SharedPreferences
                getSharedPreferences("myprefs", MODE_PRIVATE)
                        .edit()
                        .putString("logged_in_username", username)
                        .apply();

                // lets user login with create button after creating user and pass
                startActivity(new Intent(this, MainActivity.class));
                finish();

            } else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
