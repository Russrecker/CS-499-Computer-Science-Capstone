package model;

/**
 * This class is used to store a user's weight and date.
 * Each entry has an ID, a date, and a weight.
 */
public class WeightEntry {
    private String weight;
    private final String date;
    private final int id;

    /**
     * Makes a new weight entry with an id, date, and weight.
     *
     * @param id unique id for this entry
     * @param date the date of the entry
     * @param weight the weight for that day
     */
    public WeightEntry(int id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    /**
     * Gets the date of this entry
     *
     * @return date as a String
     */
    public String getDate() {

        return date;
    }

    /**
     * Gets the weight of this entry
     *
     * @return weight as a String
     */
    public String getWeight() {

        return weight;
    }

    /**
     * Updates the weight value
     *
     * @param weight the new weight to save
     */
    public void setWeight(String weight) {

        this.weight = weight;
    }

    /**
     * Gets the ID of this entry
     *
     * @return entry ID as an int
     */
    public int getId() {

        return id;
    }
}
