package com.weighttracker.app.ui.weight;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.weighttracker.app.R;

import java.util.List;

import model.WeightEntry;

/**
 * Adapter for showing weight entries in a list.
 * This connects the weight data to the screen.
 */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightHolder> {

    // List of all weight entries
    private final List<WeightEntry> weightList;
    // Used to handle edit/delete actions
    private final WeightItemActionListener listener;

    /**
     * Constructor sets up the adapter with the weight list and listener
     *
     * @param weightList list of weights to show
     * @param listener used for edit and delete actions
     */
    public WeightAdapter(List<WeightEntry> weightList, WeightItemActionListener listener) {
        this.weightList = weightList;
        this.listener = listener;
    }

    /**
     * Called when a new item view needs to be made.
     *
     * @param parent the parent view group
     * @param viewType type of view (we only have one here)
     * @return new WeightHolder (the item layout)
     */
    @NonNull
    @Override
    public WeightHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        return new WeightHolder(layoutInflater, parent);
    }

    /**
     * Called to show the data at a certain spot in the list.
     *
     * @param holder the holder for the item view
     * @param position where we are in the list
     */
    @Override
    public void onBindViewHolder(WeightHolder holder, int position) {
        WeightEntry weightEntry = weightList.get(position);
        holder.bind(weightEntry, listener);
    }

    /**
     * Tells how many items are in the list
     *
     * @return size of the weight list
     */
    @Override
    public int getItemCount() {

        return weightList.size();
    }

    /**
     * Holds each item in the list
     */
    public static class WeightHolder extends RecyclerView.ViewHolder {

        private final TextView dateEntryText;
        private final TextView weightEntryText;
        private final ImageView menuIcon;

        /**
         * Sets up the views for each row
         *
         * @param inflater used to create the layout
         * @param parent the parent layout
         */
        public WeightHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_of_weight, parent, false));
            dateEntryText = itemView.findViewById(R.id.date_entry);
            weightEntryText = itemView.findViewById(R.id.weight_entry);
            menuIcon = itemView.findViewById(R.id.menuIcon);

        }

        /**
         * Fills in the row with data and handles the menu
         *
         * @param weightEntry one weight entry
         * @param listener handles clicks on edit or delete
         */
        public void bind(WeightEntry weightEntry, WeightItemActionListener listener) {
            dateEntryText.setText(weightEntry.getDate());
            weightEntryText.setText(weightEntry.getWeight());

            // Handle menu (edit or delete) when icon is clicked
            menuIcon.setOnClickListener(view -> {
                PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
                popupMenu.inflate(R.menu.item_menu);
                popupMenu.setOnMenuItemClickListener(item -> {
                    if (item.getItemId() == R.id.menu_edit) {
                        listener.onEditRequested(weightEntry);
                        return true;
                    } else if (item.getItemId() == R.id.menu_delete) {
                        listener.onDeleteRequested(weightEntry);
                        return true;
                    }
                    return false;
                });
                popupMenu.show();
            });
        }
    }

    /**
     * This lets the screen know when edit or delete is tapped
     */
    public interface WeightItemActionListener {
        void onEditRequested(WeightEntry entry);
        void onDeleteRequested(WeightEntry entry);
    }
}

